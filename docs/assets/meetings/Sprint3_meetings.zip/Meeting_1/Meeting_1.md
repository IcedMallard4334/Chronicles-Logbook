# Sprint 3 - Meeting 1

**Project:** Digital Logbook App

**Meeting Type:** Sprint 3 Planning & Task Delegation

**Date:** 2026-09-22

**Location:** Discord Voice Channel

**Sprint:** Sprint 3 | Meeting 1

**Attendees:**
- Ethan
- Victor
- Ronald
- Athalia
- Tebogo
- Nkosinathi

**Absentees:** None (all attended)

**Minutes Taker:** Victor

---

## 1. Agenda

1.  Review Sprint 2 marker feedback.
2.  Compile new features from marker and user feedback.
3.  Integrate new features with pre-planned Sprint 3 tasks.
4.  Create user stories for all new and existing tasks.
5.  Delegate tasks to all team members.

---

## 2. Discussion Summary

### 2.1 Sprint 2 Marker Feedback

The team met with their marker/reviewer for Sprint 2 and received the following feedback on features that need to be added:

| # | Feature | Description |
| :--- | :--- | :--- |
| 1 | **FAQs** | Integrate a Frequently Asked Questions section into the application. |
| 2 | **Walkthrough Guide** | Add a walkthrough guide for the application to help new users navigate. |
| 3 | **Help Manual** | Add a help manual for users to reference when they need assistance. |
| 4 | **Theme-Responsive Background** | The background should alter with the theme change (light/dark mode). |

### 2.2 User Feedback

In addition to the marker's feedback, the team compiled features and improvements suggested by users through the Google Form feedback collected during Sprint 2.

### 2.3 Integration with Pre-Planned Sprint 3 Tasks

The team combined the new features (from marker and user feedback) with the pre-planned Sprint 3 tasks to create a comprehensive list of work for the sprint.

### 2.4 User Story Creation

The team created user stories for all new and existing tasks, ensuring each feature had clear acceptance criteria and could be estimated and prioritised.

### 2.5 Task Delegation

Tasks were delegated among all team members based on their roles, strengths, and availability.

---

## 3. Decisions Made

| Decision ID | Description |
| :--- | :--- | :--- |
| **D-001** | Integrate FAQs into the application. |
| **D-002** | Add a walkthrough guide for the application. |
| **D-003** | Add a help manual. |
| **D-004** | Make the background responsive to theme changes. |
| **D-005** | Compile and prioritise user feedback from the Google Form. |
| **D-006** | Create user stories for all Sprint 3 tasks. | 
| **D-007** | Delegate all Sprint 3 tasks to team members. |

---

## 4. Action Items

| Action | Deadline |
| :--- | :--- | :--- |
| Integrate FAQs. | Sprint 3 |
| Add walkthrough guide.  | Sprint 3 |
| Add help manual.| Sprint 3 |
| Make background theme-responsive. | Sprint 3 |
| Review and prioritise user feedback. | Sprint 3 |
| Create user stories for all tasks. | Complete |
| Delegate tasks to all members. | Complete |

---

## 5. Next Meeting

- **Type:** Sprint 3 Progress Check-in
- **Date:** 2026-09-25
- **Agenda:** Review progress on user stories and performance metrics.

---

**Minutes Approved By:**
*All Team Members*