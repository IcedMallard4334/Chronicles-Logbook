# Sprint 3 - Meeting 3

**Project:** Digital Logbook App

**Meeting Type:** Product Owner Review (In-Person)

**Date:** 2026-09-28

**Time:** [Time TBD]

**Location:** MSL Laptop Areas

**Sprint:** Sprint 3 | Meeting 3

**Attendees:**
- Ethan
- Victor
- Ronald
- Athalia
- Tebogo
- Nkosinathi
- Matthew (Product Owner / Mentor / Reviewer)

**Absentees:** None (all attended)

**Minutes Taker:** Victor

---

## 1. Agenda

1.  Review current app progress with the Product Owner.
2.  Receive feedback on documentation.
3.  Discuss additional features to differentiate the app.
4.  Finalise Sprint 3 priorities.

---

## 2. Discussion Summary

### 2.1 App Progress Review

Matthew expressed that he was **happy with the current progress** of the app. The team walked him through the latest features and improvements made during Sprint 3, and he was pleased with the direction and quality of the work.

### 2.2 Documentation Fixes

Matthew identified some documentation problems that need to be addressed before the Sprint 3 review session:

| # | Documentation Issue | Description |
| :--- | :--- | :--- |
| 1 | **User Interaction Information** | Documentation of user interaction data and feedback needs to be fixed. |
| 2 | **External API Documentation** | Documentation for the external API integration needs to be fixed. |

**Action:** Fix both documentation issues before the sprint review session.

### 2.3 Differentiating Features

The team suggested implementing one or two extra features that would separate them from other groups. Matthew provided an example:

**Example Feature:** Daily streak badges, unlocks, or awards as an incentive to make users want to interact with the app more.

This gamification element would encourage consistent usage and engagement with the Digital Logbook.

**Action:** Consider implementing daily streak badges or similar gamification features.

---

## 3. Decisions Made

| Decision ID | Description 
| :--- | :--- | :--- |
| **D-001** | Fix user interaction information documentation. |
| **D-002** | Fix external API documentation. |
| **D-003** | Consider implementing daily streak badges/unlocks/awards as a differentiating feature. |

---

## 4. Action Items

| Action | Deadline |
| :--- | :--- | :--- |
| Fix user interaction documentation. | Before Sprint 3 review session |
| Fix external API documentation. | Before Sprint 3 review session |
| Evaluate and implement gamification features (daily streaks, badges, unlocks). | Sprint 3 / Sprint 4 |
| Finalise all Sprint 3 deliverables. | Sprint 3 deadline (29 Sep) |

---

## 5. Next Meeting

- **Type:** Sprint 3 Final Sync & Retrospective
- **Date:** 2026-09-29
- **Agenda:** Finalise Sprint 3 deliverables and conduct retrospective.

---

**Minutes Approved By:**
*All Team Members*