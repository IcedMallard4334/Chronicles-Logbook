# Sprint 3 - Meeting 2

**Project:** Digital Logbook App

**Meeting Type:** Sprint 3 Progress Check-in & Performance Review

**Date:** 2026-09-25

**Location:** Discord Voice Channel

**Sprint:** Sprint 3 | Meeting 2

**Attendees:**
- Ethan
- Victor
- Ronald
- Tebogo
- Nkosinathi

**Minutes Taker:** Victor

---

## 1. Agenda

1.  Check in on progress of each team member's user stories.
2.  Assess the current state of the app.
3.  Review performance metrics.
4.  Distribute user feedback form.

---

## 2. Discussion Summary

### 2.1 Progress Check-in

The team held a check-in meeting to assess how far each member was with their assigned user stories. Each member provided an update on their progress, and any blockers were discussed.

### 2.2 Performance Metrics Review

During the meeting, the team remembered the importance of performance metrics for the app. Using the website provided by the lecturer, the team ran a performance analysis and found that the app was giving **poor performance**.

**Decision:** The team flagged this as a bug and decided to fix it immediately during the meeting.

**Outcome:** Once the team achieved good performance, they proceeded with the next agenda item.

### 2.3 User Feedback Form Distribution

With the app now performing well, the team decided to send out the Google Form for user feedback on the current state of the application. This feedback will be used to identify further improvements and validate the app's usability.

---

## 3. Decisions Made

| Decision ID | Description |
| :--- | :--- | :--- |
| **D-001** | Flag poor performance as a bug and fix immediately. |
| **D-002** | Send out Google Form for user feedback on the current state of the app. |

---

## 4. Action Items

| Action| Deadline |
| :--- | :--- | :--- |
| Fix performance issues identified by the performance analysis tool. | Complete |
| Distribute Google Form for user feedback. | Complete |
| Review user feedback once collected. | Sprint 3 |
| Continue work on individual user stories. | Sprint 3 |

---

## 5. Next Meeting

- **Type:** Product Owner Review
- **Date:** 2026-09-28
- **Location:** MSL Laptop Areas
- **Agenda:** Review progress and finalise Sprint 3 deliverables.

---

**Minutes Approved By:**
*All Team Members*