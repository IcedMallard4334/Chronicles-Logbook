# Sprint 2 - Meeting 1

**Project:** Digital Logbook App

**Meeting Type:** Sprint 1 Retrospective & Sprint 2 Task Delegation

**Date:** 2026-08-26

**Location:** DMSL004

**Sprint:** Sprint 2 | Meeting 1

**Attendees:**
- Ethan
- Victor
- Ronald
- Athalia
- Tebogo
- Nkosinathi

**Minutes Taker:** Victor

---

## 1. Agenda

1.  Review Sprint 1 marking feedback.
2.  Identify and discuss fixes required from Sprint 1.
3.  Review Sprint 2 scope and requirements.
4.  Delegate tasks for Sprint 2.

---

## 2. Discussion Summary

### 2.1 Sprint 1 Marking Feedback

The team reviewed the feedback received from the Sprint 1 marking. The following issues were identified as requiring fixes:

| # | Issue | Description |
| :--- | :--- | :--- |
| 1 | **Testing & Debugging Column** | Add a dedicated column for testing and debugging in the work tracker. |
| 2 | **Agile Motivation** | Add motivation explaining why the team uses Agile methodology. |
| 3 | **Documentation Colour Scheme** | Update the colour scheme in the documentation site for better readability and professionalism. |
| 4 | **Edit Created Fields** | Implement functionality to edit a field that has already been created in the schema editor. |
| 5 | **Live Documentation Fix** | Fix the live documentation deployment and ensure it is accessible. |
| 6 | **Motivations for Everything** | Add motivations for all decisions made throughout the project — not just major ones. |

### 2.2 Sprint 2 Work Review & Task Delegation

After discussing the Sprint 1 fixes, the team moved on to review the work required for Sprint 2. The team reviewed the project brief and identified the features and tasks that needed to be completed during this sprint.

Tasks were then delegated among team members based on their roles and availability.

---

## 3. Decisions Made

| Decision ID | Description |
| :--- | :--- | :--- |
| **D-001** | Add a testing and debugging column to the work tracker.
| **D-002** | Add motivation for using Agile methodology to documentation.
| **D-003** | Update the documentation colour scheme.
| **D-004** | Implement editing for already-created fields.
| **D-005** | Fix the live documentation deployment.
| **D-006** | Add motivations for all decisions throughout the project.
| **D-007** | Review Sprint 2 work and delegate tasks.

---

**Minutes Approved By:**
*All Team Members*