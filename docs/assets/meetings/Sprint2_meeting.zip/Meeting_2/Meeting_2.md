# Sprint 2 - Meeting 2

**Project:** Digital Logbook App

**Meeting Type:** Sprint 2 Planning & Usability Review

**Date:** 2026-09-02

**Location:** Wartenweiler Library Focus Room 2

**Sprint:** Sprint 2 | Meeting 2

**Attendees:**
- Ethan
- Victor
- Ronald
- Athalia
- Tebogo
- Nkosinathi

**Minutes Taker:** Victor

---

## 1. Agenda

1.  Full walkthrough of the current app.
2.  Identify usability changes needed.
3.  Implement external API integration (Google Calendar).
4.  Document all required changes and new functionalities.
5.  Delegate tasks for Sprint 2.

---

## 2. Discussion Summary

### 2.1 Full App Walkthrough

The team conducted a complete walkthrough of the current state of the app. As the team moved through each feature, they discussed possible usability changes that needed to be made. The general consensus was that the app currently felt **too difficult to use**, and improvements were needed to make it more intuitive and user-friendly.

### 2.2 Google Calendar External API Integration

Ethan implemented an external API integration that allows the app to connect to the team's own personal Google Calendar. This integration enables better workflow management by allowing events to be tracked and synced between the Digital Logbook and Google Calendar.

### 2.3 Documentation of Changes

Athalia created a Word document capturing all the changes discussed during the walkthrough, including:

- Usability improvements identified during the walkthrough.
- New functionalities required for Sprint 2.
- The Google Calendar API integration.

This document served as the basis for task delegation.

### 2.4 Task Delegation

Using the document created by Athalia, the team delegated tasks among themselves based on their roles, strengths, and availability.

---

## 3. Decisions Made

| Decision ID | Description |
| :--- | :--- | :--- |
| **D-001** | Improve overall app usability — the app currently feels too difficult to use. |
| **D-002** | Integrate Google Calendar as an external API for workflow management. |
| **D-003** | Document all required changes and new functionalities in a central document. |
| **D-004** | Delegate Sprint 2 tasks based on the documented changes. |

---

---

**Minutes Approved By:**
*All Team Members*