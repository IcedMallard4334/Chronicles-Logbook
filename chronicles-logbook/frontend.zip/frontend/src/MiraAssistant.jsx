import { useEffect, useRef, useState } from "react"
import "./MiraAssistant.css"

const PROMPTS = [
  { title: "Write a clearer update", detail: "Turn rough notes into a useful log entry.", prompt: "Help me write a clear project update. Ask me what I worked on, what I learned, and what comes next." },
  { title: "Plan a focused session", detail: "Give your next work session a direction.", prompt: "Help me plan a focused work session." },
  { title: "Start a project", detail: "Shape an idea into a project proposal.", prompt: "Help me create a project. Ask me for its name and description before proposing it." },
]

function MiraMark() {
  return <span className="mira-mark" aria-hidden="true"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 17V7l8 8 8-8v10" /><path d="M12 3v3M10.5 4.5h3" /></svg></span>
}

function ProjectProposal({ action, saving, onConfirm, onCancel }) {
  if (!action || action.type !== "create_project") return null
  const { name, description } = action.payload
  return <section className="mira-project-proposal" aria-label="Proposed project">
    <span className="mira-message-label">Project proposal</span>
    <strong>{name}</strong>
    {description && <p>{description}</p>}
    <p className="mira-proposal-note">Mira has not created anything yet. Review this project before confirming.</p>
    <div className="mira-proposal-actions">
      <button type="button" className="btn-secondary" onClick={onCancel} disabled={saving}>Cancel</button>
      <button type="button" className="btn-primary" onClick={onConfirm} disabled={saving}>{saving ? "Creating…" : "Create project"}</button>
    </div>
  </section>
}

function Conversation({ messages, sending, error, onSend, onClear, pendingAction, actionSaving, onConfirmAction, onCancelAction, onOpenProject, compact = false }) {
  const [draft, setDraft] = useState("")
  const feedRef = useRef(null)

  useEffect(() => {
    if (feedRef.current) feedRef.current.scrollTop = feedRef.current.scrollHeight
  }, [messages, sending, error])

  const send = async (value = draft) => {
    const message = value.trim()
    if (!message || sending) return
    setDraft("")
    await onSend(message)
  }

  const handleKeyDown = (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault()
      send()
    }
  }

  return <>
    <div className="mira-feed" ref={feedRef} aria-live="polite" aria-label="Mira conversation">
      {!messages.length && !sending && <div className="mira-welcome">
        <div><h2>Make room for your next idea.</h2><p>Bring a rough idea, a work update, or a plan. Let’s give it a clear next step.</p></div>
        <div className="mira-prompts" aria-label="Suggested prompts">
          {PROMPTS.map(({ title, detail, prompt }, index) => <button type="button" key={title} onClick={() => { setDraft(prompt); document.getElementById(compact ? "mira-compact-input" : "mira-full-input")?.focus() }}><span className="mira-prompt-number" aria-hidden="true">0{index + 1}</span><strong>{title}</strong><span>{detail}</span><span className="mira-prompt-arrow" aria-hidden="true">↗</span></button>)}
        </div>
      </div>}
      {messages.map(message => <article className={`mira-message mira-message-${message.role}`} key={message.id}>
        <span className="mira-message-label">{message.role === "user" ? "You" : "Mira"}</span>
        <p>{message.content}</p>
        {message.projectId && <button type="button" className="mira-open-project" onClick={() => onOpenProject(message.projectId)}>Open project →</button>}
      </article>)}
      <ProjectProposal action={pendingAction} saving={actionSaving} onConfirm={onConfirmAction} onCancel={onCancelAction} />
      {sending && <div className="mira-typing" role="status"><MiraMark /> <span>Mira is thinking<span className="mira-dots">…</span></span></div>}
      {error && <div className="mira-error" role="alert"><span>{error.message}</span>{error.retryMessage && <button type="button" onClick={() => onSend(error.retryMessage)}>Retry</button>}</div>}
    </div>
    <form className="mira-composer" onSubmit={(event) => { event.preventDefault(); send() }}>
      <label className="sr-only" htmlFor={compact ? "mira-compact-input" : "mira-full-input"}>Message Mira</label>
      <textarea id={compact ? "mira-compact-input" : "mira-full-input"} value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={handleKeyDown} maxLength={2000} rows={compact ? 2 : 3} placeholder="What are you working on?" />
      <div className="mira-composer-actions"><span><span className="mira-keyboard-hint">Enter to send · Shift + Enter for a new line</span><span>{draft.length}/2000</span></span><button className="btn-primary" type="submit" disabled={!draft.trim() || sending}>Send</button></div>
      <p className="mira-footnote">Review Mira’s suggestions. Project creation always needs your confirmation. Chats clear when you refresh.</p>
    </form>
    {messages.length > 0 && <button type="button" className="mira-clear" onClick={onClear}>Clear conversation</button>}
  </>
}

export function MiraAssistantPage({ conversation }) {
  return <section className="mira-page workspace-page" aria-labelledby="mira-title">
    <header className="mira-page-header"><div className="mira-heading-identity"><MiraMark /><div><h1 id="mira-title">Mira <span>by Chronicles</span></h1><p>A thinking partner for your project work.</p></div></div><span className="mira-page-badge">Ideas → plans → progress</span></header>
    <p className="mira-permissions-link"><a href="/mira-permissions">Mira permissions · review or change access</a></p>
    <Conversation {...conversation} />
  </section>
}

export function MiraLauncher({ conversation, open, onToggle, onOpenFull }) {
  return <div className="mira-launcher">
    {open && <section className="mira-panel" aria-label="Mira assistant">
      <header><div><MiraMark /><span><strong>Mira</strong><small>Chronicles assistant</small></span></div><div><button type="button" className="mira-panel-link" onClick={onOpenFull}>Open full assistant</button><button type="button" aria-label="Close Mira" className="mira-close" onClick={onToggle}>×</button></div></header>
      <Conversation {...conversation} compact />
    </section>}
    <button type="button" className="mira-launch-button" aria-label={open ? "Close Mira assistant" : "Open Mira assistant"} aria-expanded={open} onClick={onToggle}><MiraMark /><span>Mira</span></button>
  </div>
}
